export { default } from "./src/App";
