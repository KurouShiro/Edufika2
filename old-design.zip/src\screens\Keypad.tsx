import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { AppLanguage, tr } from "../i18n";
import { palette } from "./Layout";

type KeypadProps = {
  language: AppLanguage;
  onPressDigit: (value: string) => void;
  onBackspace: () => void;
  onClear?: () => void;
};

const rows = [
  ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
  ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
  ["A", "S", "D", "F", "G", "H", "J", "K", "L", "_"],
  ["SHIFT", "Z", "X", "C", "V", "B", "N", "M", "CLR", "BACK"],
];
const letterPattern = /^[A-Z]$/;

export default function Keypad({ language, onPressDigit, onBackspace, onClear }: KeypadProps) {
  const [useLowercase, setUseLowercase] = useState(false);

  const getDisplayKey = (key: string): string => {
    if (key === "SHIFT") {
      return useLowercase ? "abc" : "ABC";
    }
    if (letterPattern.test(key)) {
      return useLowercase ? key.toLowerCase() : key;
    }
    return key;
  };

  return (
    <View style={styles.root}>
      {rows.map((row, rowIndex) => (
        <View key={`row-${rowIndex}`} style={styles.row}>
          {row.map((key) => {
            const isClear = key === "CLR";
            const isBack = key === "BACK";
            const isShift = key === "SHIFT";
            const isLetter = letterPattern.test(key);
            return (
              <Pressable
                key={`${rowIndex}-${key}`}
                style={({ pressed }) => [
                  styles.key,
                  rowIndex === 3 && (isClear || isBack || isShift) ? styles.specialKey : null,
                  isClear ? styles.clearKey : null,
                  isShift ? styles.shiftKey : null,
                  isShift && useLowercase ? styles.shiftKeyActive : null,
                  pressed ? styles.keyPressed : null,
                ]}
                onPress={() => {
                  if (isShift) {
                    setUseLowercase((value) => !value);
                    return;
                  }
                  if (isClear) {
                    onClear?.();
                    return;
                  }
                  if (isBack) {
                    onBackspace();
                    return;
                  }
                  const input = useLowercase && isLetter ? key.toLowerCase() : key;
                  onPressDigit(input);
                }}
              >
                <Text
                  style={[
                    styles.keyText,
                    isClear ? styles.clearText : null,
                    isShift && useLowercase ? styles.shiftTextActive : null,
                  ]}
                >
                  {key === "CLR"
                    ? tr(language, "HAPUS", "CLR")
                    : key === "BACK"
                      ? tr(language, "BKSP", "BACK")
                      : getDisplayKey(key)}
                </Text>
              </Pressable>
            );
          })}
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    marginTop: 6,
    gap: 6,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 6,
  },
  key: {
    flex: 1,
    borderWidth: 1,
    borderColor: "rgba(57,255,20,0.24)",
    borderRadius: 0,
    paddingVertical: 10,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(57,255,20,0.06)",
    minHeight: 42,
  },
  specialKey: {
    flex: 1.45,
    backgroundColor: "rgba(57,255,20,0.14)",
  },
  clearKey: {
    borderColor: "rgba(255,65,65,0.5)",
    backgroundColor: "rgba(255,65,65,0.08)",
  },
  keyPressed: {
    opacity: 0.82,
    transform: [{ scale: 0.98 }],
  },
  keyText: {
    color: palette.neon,
    fontFamily: "JetBrainsMono-Bold",
    fontSize: 10,
    letterSpacing: 0.9,
  },
  clearText: {
    color: palette.warning,
  },
  shiftKey: {
    borderColor: "rgba(57,255,20,0.4)",
    backgroundColor: "rgba(57,255,20,0.12)",
  },
  shiftKeyActive: {
    borderColor: "rgba(57,255,20,0.9)",
    backgroundColor: "rgba(57,255,20,0.24)",
  },
  shiftTextActive: {
    color: "#ffffff",
  },
});
